# Nangarhar — Dr Maseer Baryal Safi Official App

Android project for the official website:
https://drmaseerbaryal2019.netlify.app

The app loads the live website, so published website updates appear when the app is online.
Build with JDK 17, Gradle 8.9 and Android Gradle Plugin 8.7.3 using `gradle assembleDebug`.
