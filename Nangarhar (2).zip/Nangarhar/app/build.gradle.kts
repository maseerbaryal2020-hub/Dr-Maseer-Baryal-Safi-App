plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "af.nangarhar.drmaser"
    compileSdk = 35
    defaultConfig {
        applicationId = "af.nangarhar.drmaser"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
